package com.campusfind.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

// Local SQLite database: users + items
public class DbHelper extends SQLiteOpenHelper {

    private static DbHelper instance;

    public static synchronized DbHelper get(Context context) {
        if (instance == null) instance = new DbHelper(context.getApplicationContext());
        return instance;
    }

    private DbHelper(Context context) {
        super(context, "campusfind.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (email TEXT PRIMARY KEY, name TEXT, salt TEXT, hash TEXT)");
        db.execSQL("CREATE TABLE items (id TEXT PRIMARY KEY, type TEXT, title TEXT, category TEXT, "
                + "place TEXT, date TEXT, latitude REAL, longitude REAL, contact TEXT, "
                + "reported_by TEXT, reporter_email TEXT, status TEXT)");

        // 6 starter items
        starter(db, "CF-01", "Found", "Black leather wallet", "Wallets & Cards", "Main Library", "2026-11-12", 31.38955, 74.24070);
        starter(db, "CF-02", "Lost", "Casio fx-991ES calculator", "Electronics", "CS Block", "2026-11-11", 31.38990, 74.24120);
        starter(db, "CF-03", "Found", "Student ID card", "Wallets & Cards", "Cafeteria", "2026-11-10", 31.38880, 74.24010);
        starter(db, "CF-04", "Lost", "Blue water bottle", "Other", "Sports Ground", "2026-11-09", 31.38800, 74.24200);
        starter(db, "CF-05", "Found", "Car keys, red keychain", "Keys", "Main Parking", "2026-11-08", 31.39050, 74.23950);
        starter(db, "CF-06", "Lost", "32 GB USB flash drive", "Electronics", "Mosque", "2026-11-07", 31.38920, 74.24180);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    private void starter(SQLiteDatabase db, String id, String type, String title, String category,
                         String place, String date, double lat, double lon) {
        ContentValues v = new ContentValues();
        v.put("id", id);
        v.put("type", type);
        v.put("title", title);
        v.put("category", category);
        v.put("place", place);
        v.put("date", date);
        v.put("latitude", lat);
        v.put("longitude", lon);
        v.put("contact", "03001234567");
        v.put("reported_by", "Student Affairs");
        v.put("reporter_email", "");
        v.put("status", "Open");
        db.insert("items", null, v);
    }

    // ---------------- users ----------------

    public boolean emailExists(String email) {
        Cursor c = getReadableDatabase().rawQuery("SELECT email FROM users WHERE email = ?", new String[]{email});
        boolean exists = c.moveToFirst();
        c.close();
        return exists;
    }

    public void addUser(String name, String email, String password) {
        byte[] bytes = new byte[16];
        new SecureRandom().nextBytes(bytes);
        String salt = Base64.encodeToString(bytes, Base64.NO_WRAP);

        ContentValues v = new ContentValues();
        v.put("email", email);
        v.put("name", name);
        v.put("salt", salt);
        v.put("hash", hash(salt, password));
        getWritableDatabase().insert("users", null, v);
    }

    // returns the user's name if email + password are right, otherwise null
    public String login(String email, String password) {
        String name = null;
        Cursor c = getReadableDatabase().rawQuery("SELECT name, salt, hash FROM users WHERE email = ?", new String[]{email});
        if (c.moveToFirst() && hash(c.getString(1), password).equals(c.getString(2))) {
            name = c.getString(0);
        }
        c.close();
        return name;
    }

    // passwords are never stored as plain text: SHA-256 of salt + password
    private String hash(String salt, String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] out = md.digest((salt + password).getBytes("UTF-8"));
            return Base64.encodeToString(out, Base64.NO_WRAP);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // ---------------- items ----------------

    // newest date first, same date -> higher ID first
    public List<Item> getItems() {
        List<Item> list = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT * FROM items ORDER BY date DESC, CAST(SUBSTR(id, 4) AS INTEGER) DESC", null);
        while (c.moveToNext()) list.add(read(c));
        c.close();
        return list;
    }

    public Item getItem(String id) {
        Cursor c = getReadableDatabase().rawQuery("SELECT * FROM items WHERE id = ?", new String[]{id});
        Item item = c.moveToFirst() ? read(c) : null;
        c.close();
        return item;
    }

    // CF-07, CF-08, ...
    public String nextId() {
        Cursor c = getReadableDatabase().rawQuery("SELECT MAX(CAST(SUBSTR(id, 4) AS INTEGER)) FROM items", null);
        c.moveToFirst();
        int next = c.getInt(0) + 1;
        c.close();
        return String.format(Locale.US, "CF-%02d", next);
    }

    public void addItem(Item i) {
        ContentValues v = new ContentValues();
        v.put("id", i.id);
        v.put("type", i.type);
        v.put("title", i.title);
        v.put("category", i.category);
        v.put("place", i.place);
        v.put("date", i.date);
        v.put("latitude", i.latitude);
        v.put("longitude", i.longitude);
        v.put("contact", i.contact);
        v.put("reported_by", i.reportedBy);
        v.put("reporter_email", i.reporterEmail);
        v.put("status", i.status);
        getWritableDatabase().insert("items", null, v);
    }

    public void markReturned(String id) {
        ContentValues v = new ContentValues();
        v.put("status", "Returned");
        getWritableDatabase().update("items", v, "id = ?", new String[]{id});
    }

    private Item read(Cursor c) {
        Item i = new Item();
        i.id = c.getString(c.getColumnIndexOrThrow("id"));
        i.type = c.getString(c.getColumnIndexOrThrow("type"));
        i.title = c.getString(c.getColumnIndexOrThrow("title"));
        i.category = c.getString(c.getColumnIndexOrThrow("category"));
        i.place = c.getString(c.getColumnIndexOrThrow("place"));
        i.date = c.getString(c.getColumnIndexOrThrow("date"));
        i.latitude = c.getDouble(c.getColumnIndexOrThrow("latitude"));
        i.longitude = c.getDouble(c.getColumnIndexOrThrow("longitude"));
        i.contact = c.getString(c.getColumnIndexOrThrow("contact"));
        i.reportedBy = c.getString(c.getColumnIndexOrThrow("reported_by"));
        i.reporterEmail = c.getString(c.getColumnIndexOrThrow("reporter_email"));
        i.status = c.getString(c.getColumnIndexOrThrow("status"));
        return i;
    }
}
