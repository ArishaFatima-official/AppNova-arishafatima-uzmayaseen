package com.campusfind.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private ItemAdapter adapter;
    private TextView tvEmpty;
    private String filter = "All";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        tvEmpty = view.findViewById(R.id.tv_empty);

        String first = new Session(requireContext()).getName().split(" ")[0];
        ((TextView) view.findViewById(R.id.tv_greeting)).setText("Hi, " + first);

        adapter = new ItemAdapter(item -> {
            Intent i = new Intent(requireContext(), DetailActivity.class);
            i.putExtra("id", item.id);
            startActivity(i);
        });
        RecyclerView recycler = view.findViewById(R.id.recycler);
        recycler.setLayoutManager(new LinearLayoutManager(requireContext()));
        recycler.setAdapter(adapter);

        ChipGroup chips = view.findViewById(R.id.chip_group);
        chips.setOnCheckedStateChangeListener((group, ids) -> {
            int id = ids.isEmpty() ? R.id.chip_all : ids.get(0);
            if (id == R.id.chip_lost) filter = "Lost";
            else if (id == R.id.chip_found) filter = "Found";
            else filter = "All";
            loadItems();
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        loadItems(); // refresh so new items / status changes show at once
    }

    private void loadItems() {
        List<Item> shown = new ArrayList<>();
        for (Item item : DbHelper.get(requireContext()).getItems()) {
            if (filter.equals("All") || item.type.equals(filter)) shown.add(item);
        }
        adapter.setItems(shown);
        tvEmpty.setVisibility(shown.isEmpty() ? View.VISIBLE : View.GONE);
    }
}
