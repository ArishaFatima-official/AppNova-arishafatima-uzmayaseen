package com.campusfind.app;

import android.content.Context;
import android.content.SharedPreferences;

// Keeps the logged-in user until Logout
public class Session {
    private final SharedPreferences prefs;

    public Session(Context context) {
        prefs = context.getSharedPreferences("session", Context.MODE_PRIVATE);
    }

    public void login(String name, String email) {
        prefs.edit().putString("name", name).putString("email", email).apply();
    }

    public boolean isLoggedIn() {
        return prefs.getString("email", null) != null;
    }

    public String getName() {
        return prefs.getString("name", "");
    }

    public String getEmail() {
        return prefs.getString("email", "");
    }

    public void logout() {
        prefs.edit().clear().apply();
    }
}
