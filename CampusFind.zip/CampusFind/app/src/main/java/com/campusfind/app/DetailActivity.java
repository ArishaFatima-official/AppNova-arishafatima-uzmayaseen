package com.campusfind.app;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.Locale;

public class DetailActivity extends AppCompatActivity {

    private DbHelper db;
    private Session session;
    private String itemId;
    private LinearLayout rows;
    private MaterialButton btnReturn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        db = DbHelper.get(this);
        session = new Session(this);
        itemId = getIntent().getStringExtra("id");
        rows = findViewById(R.id.rows);
        btnReturn = findViewById(R.id.btn_return);

        ((com.google.android.material.appbar.MaterialToolbar) findViewById(R.id.toolbar))
                .setNavigationOnClickListener(v -> finish());

        findViewById(R.id.btn_maps).setOnClickListener(v -> openMaps());

        btnReturn.setOnClickListener(v -> {
            db.markReturned(itemId);
            show();
            Snackbar.make(v, "Marked as returned", Snackbar.LENGTH_SHORT).show();
        });

        show();
    }

    // fills the screen from the database
    private void show() {
        Item item = db.getItem(itemId);
        if (item == null) {
            finish();
            return;
        }

        TextView tag = findViewById(R.id.tv_type);
        tag.setText(item.type.toUpperCase());
        tag.setBackgroundResource(item.type.equals("Lost") ? R.drawable.bg_tag_lost : R.drawable.bg_tag_found);
        ((TextView) findViewById(R.id.tv_title)).setText(item.title);

        rows.removeAllViews();
        addRow("ID", item.id);
        addRow("Category", item.category);
        addRow("Place", item.place);
        addRow("Date", item.displayDate());
        addRow("Coordinates", String.format(Locale.US, "%.5f, %.5f", item.latitude, item.longitude));
        addRow("Contact", item.contact);
        addRow("Reported by", item.reportedBy);
        addRow("Status", item.status);

        // only the user who reported it can mark it as returned
        boolean mine = item.reporterEmail.equals(session.getEmail());
        btnReturn.setVisibility(mine && item.status.equals("Open") ? View.VISIBLE : View.GONE);
    }

    private void addRow(String label, String value) {
        View row = LayoutInflater.from(this).inflate(R.layout.detail_row, rows, false);
        ((TextView) row.findViewById(R.id.tv_label)).setText(label);
        ((TextView) row.findViewById(R.id.tv_value)).setText(value);
        rows.addView(row);
    }

    private void openMaps() {
        Item item = db.getItem(itemId);
        String point = String.format(Locale.US, "%.5f,%.5f", item.latitude, item.longitude);
        Uri uri = Uri.parse("geo:" + point + "?q=" + point + "(" + Uri.encode(item.title) + ")");
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException e) {
            Snackbar.make(rows, "No maps app found on this phone", Snackbar.LENGTH_LONG).show();
        }
    }
}
