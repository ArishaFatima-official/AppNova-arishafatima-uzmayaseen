package com.campusfind.app;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

// One lost/found item
public class Item {
    public String id, type, title, category, place, date, contact;
    public String reportedBy, reporterEmail, status;
    public double latitude, longitude;
    public float distance = -1; // metres, only used on the Nearby tab

    // date is stored as yyyy-MM-dd (sorts correctly) and shown as dd-MMM-yyyy
    public String displayDate() {
        try {
            Date d = new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(date);
            return new SimpleDateFormat("dd-MMM-yyyy", Locale.US).format(d);
        } catch (ParseException e) {
            return date;
        }
    }
}
