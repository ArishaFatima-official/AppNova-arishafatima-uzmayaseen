package com.campusfind.app;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

// Shows items as cards (used by Home and Nearby)
public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.Holder> {

    public interface OnItemClick {
        void onClick(Item item);
    }

    private List<Item> items = new ArrayList<>();
    private final OnItemClick listener;

    public ItemAdapter(OnItemClick listener) {
        this.listener = listener;
    }

    public void setItems(List<Item> items) {
        this.items = items;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row, parent, false);
        return new Holder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder h, int position) {
        Item item = items.get(position);
        boolean lost = item.type.equals("Lost");
        h.type.setText(item.type.toUpperCase());
        h.type.setBackgroundResource(lost ? R.drawable.bg_tag_lost : R.drawable.bg_tag_found);
        h.strip.setBackgroundColor(ContextCompat.getColor(h.itemView.getContext(), lost ? R.color.lost : R.color.found));
        h.id.setText(item.id);
        h.title.setText(item.title);
        h.info.setText(item.category + " • " + item.place);
        h.date.setText(item.displayDate());
        h.status.setVisibility(item.status.equals("Returned") ? View.VISIBLE : View.GONE);

        if (item.distance >= 0) {
            h.distance.setVisibility(View.VISIBLE);
            if (item.distance < 1000) {
                h.distance.setText(String.format(Locale.US, "%d m", Math.round(item.distance)));
            } else {
                h.distance.setText(String.format(Locale.US, "%.1f km", item.distance / 1000));
            }
        } else {
            h.distance.setVisibility(View.GONE);
        }

        h.itemView.setOnClickListener(v -> listener.onClick(item));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class Holder extends RecyclerView.ViewHolder {
        TextView type, id, status, title, info, date, distance;
        View strip;

        Holder(View v) {
            super(v);
            strip = v.findViewById(R.id.v_strip);
            type = v.findViewById(R.id.tv_type);
            id = v.findViewById(R.id.tv_id);
            status = v.findViewById(R.id.tv_status);
            title = v.findViewById(R.id.tv_title);
            info = v.findViewById(R.id.tv_info);
            date = v.findViewById(R.id.tv_date);
            distance = v.findViewById(R.id.tv_distance);
        }
    }
}
