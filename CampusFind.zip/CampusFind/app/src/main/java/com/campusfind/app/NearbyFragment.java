package com.campusfind.app;

import android.Manifest;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Collections;
import java.util.List;

public class NearbyFragment extends Fragment {

    private ItemAdapter adapter;
    private TextView tvMessage;

    private final ActivityResultLauncher<String> permissionLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted || LocationHelper.hasPermission(requireContext())) loadNearby();
                else showMessage("Location permission is required to see nearby items");
            });

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_nearby, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        tvMessage = view.findViewById(R.id.tv_message);

        adapter = new ItemAdapter(item -> {
            Intent i = new Intent(requireContext(), DetailActivity.class);
            i.putExtra("id", item.id);
            startActivity(i);
        });
        RecyclerView recycler = view.findViewById(R.id.recycler);
        recycler.setLayoutManager(new LinearLayoutManager(requireContext()));
        recycler.setAdapter(adapter);

        view.findViewById(R.id.btn_refresh).setOnClickListener(v -> start());
        start();
    }

    private void start() {
        if (LocationHelper.hasPermission(requireContext())) loadNearby();
        else permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION);
    }

    private void loadNearby() {
        showMessage("Finding your location...");
        LocationHelper.getLocation(requireContext(), new LocationHelper.Callback() {
            @Override
            public void onLocation(Location me) {
                if (!isAdded()) return;
                List<Item> items = DbHelper.get(requireContext()).getItems();
                for (Item item : items) {
                    float[] result = new float[1];
                    Location.distanceBetween(me.getLatitude(), me.getLongitude(), item.latitude, item.longitude, result);
                    item.distance = result[0];
                }
                // nearest first
                Collections.sort(items, (a, b) -> Float.compare(a.distance, b.distance));
                adapter.setItems(items);
                tvMessage.setVisibility(View.GONE);
            }

            @Override
            public void onError(String message) {
                if (isAdded()) showMessage(message);
            }
        });
    }

    private void showMessage(String text) {
        tvMessage.setText(text);
        tvMessage.setVisibility(View.VISIBLE);
    }
}
