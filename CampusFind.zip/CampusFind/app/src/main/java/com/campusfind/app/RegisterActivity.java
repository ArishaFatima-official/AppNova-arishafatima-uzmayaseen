package com.campusfind.app;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        TextInputLayout tilName = findViewById(R.id.til_name);
        TextInputLayout tilEmail = findViewById(R.id.til_email);
        TextInputLayout tilPassword = findViewById(R.id.til_password);
        TextInputLayout tilConfirm = findViewById(R.id.til_confirm);
        TextInputEditText etName = findViewById(R.id.et_name);
        TextInputEditText etEmail = findViewById(R.id.et_email);
        TextInputEditText etPassword = findViewById(R.id.et_password);
        TextInputEditText etConfirm = findViewById(R.id.et_confirm);

        findViewById(R.id.btn_register).setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String email = etEmail.getText().toString().trim().toLowerCase();
            String password = etPassword.getText().toString();
            String confirm = etConfirm.getText().toString();

            tilName.setError(null);
            tilEmail.setError(null);
            tilPassword.setError(null);
            tilConfirm.setError(null);
            boolean ok = true;

            if (!name.matches("[A-Za-z ]{3,}")) {
                tilName.setError("Letters and spaces only, at least 3 characters");
                ok = false;
            }
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                tilEmail.setError("Enter a valid email");
                ok = false;
            }
            if (password.length() < 6 || !password.matches(".*\\d.*")) {
                tilPassword.setError("At least 6 characters, including 1 digit");
                ok = false;
            }
            if (!confirm.equals(password)) {
                tilConfirm.setError("Passwords do not match");
                ok = false;
            }
            if (!ok) return;

            DbHelper db = DbHelper.get(this);
            if (db.emailExists(email)) {
                tilEmail.setError("An account with this email already exists");
                return;
            }

            db.addUser(name, email, password);
            new Session(this).login(name, email);
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
        });

        findViewById(R.id.tv_go_login).setOnClickListener(v -> finish());
    }
}
