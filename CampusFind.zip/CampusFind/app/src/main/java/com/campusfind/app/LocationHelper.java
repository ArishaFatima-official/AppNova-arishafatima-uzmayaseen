package com.campusfind.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;

import androidx.core.content.ContextCompat;
import androidx.core.location.LocationManagerCompat;

// Gets the phone's current GPS location (no Google Play services needed)
public class LocationHelper {

    public interface Callback {
        void onLocation(Location location);

        void onError(String message);
    }

    public static boolean hasPermission(Context c) {
        return ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @SuppressLint("MissingPermission")
    public static void getLocation(Context c, Callback callback) {
        if (!hasPermission(c)) {
            callback.onError("Location permission is required");
            return;
        }
        LocationManager lm = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
        boolean fine = ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;

        final String provider;
        if (fine && lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            provider = LocationManager.GPS_PROVIDER;
        } else if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
            provider = LocationManager.NETWORK_PROVIDER;
        } else {
            callback.onError("Please turn on Location in your phone settings");
            return;
        }

        LocationManagerCompat.getCurrentLocation(lm, provider, null, ContextCompat.getMainExecutor(c), location -> {
            if (location == null) location = lm.getLastKnownLocation(provider);
            if (location != null) callback.onLocation(location);
            else callback.onError("Could not get your location. Try again.");
        });
    }
}
