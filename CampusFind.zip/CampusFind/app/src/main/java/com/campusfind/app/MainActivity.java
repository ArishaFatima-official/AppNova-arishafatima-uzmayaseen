package com.campusfind.app;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView nav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!new Session(this).isLoggedIn()) { // nobody logged in -> back to Login
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_main);
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        nav = findViewById(R.id.bottom_nav);

        nav.setOnItemSelectedListener(menuItem -> {
            int id = menuItem.getItemId();
            Fragment fragment;
            if (id == R.id.nav_home) {
                fragment = new HomeFragment();
                toolbar.setTitle("CampusFind");
            } else if (id == R.id.nav_nearby) {
                fragment = new NearbyFragment();
                toolbar.setTitle("Nearby items");
            } else if (id == R.id.nav_report) {
                fragment = new ReportFragment();
                toolbar.setTitle("Report an item");
            } else {
                fragment = new ProfileFragment();
                toolbar.setTitle("Profile");
            }
            getSupportFragmentManager().beginTransaction().replace(R.id.container, fragment).commit();
            return true;
        });

        if (savedInstanceState == null) nav.setSelectedItemId(R.id.nav_home);
    }

    // used by the fragments to show a message above the bottom bar
    public void showMessage(String message) {
        Snackbar.make(findViewById(R.id.root), message, Snackbar.LENGTH_LONG).setAnchorView(nav).show();
    }

    public void goHome(String message) {
        nav.setSelectedItemId(R.id.nav_home);
        showMessage(message);
    }
}
