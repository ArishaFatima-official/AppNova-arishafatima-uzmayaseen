package com.campusfind.app;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Session session = new Session(this);
        if (session.isLoggedIn()) { // already logged in -> skip login
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_login);

        TextInputEditText etEmail = findViewById(R.id.et_email);
        TextInputEditText etPassword = findViewById(R.id.et_password);
        TextView goRegister = findViewById(R.id.tv_go_register);

        findViewById(R.id.btn_login).setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim().toLowerCase();
            String password = etPassword.getText().toString();

            String name = null;
            if (Patterns.EMAIL_ADDRESS.matcher(email).matches() && !password.isEmpty()) {
                name = DbHelper.get(this).login(email, password);
            }

            if (name == null) {
                Snackbar.make(v, "Invalid email or password", Snackbar.LENGTH_LONG).show();
                return;
            }
            session.login(name, email);
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });

        goRegister.setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));
    }
}
