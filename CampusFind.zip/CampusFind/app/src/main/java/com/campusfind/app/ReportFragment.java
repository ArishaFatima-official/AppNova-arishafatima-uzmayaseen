package com.campusfind.app;

import android.Manifest;
import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ReportFragment extends Fragment {

    private static final String[] CATEGORIES = {"Electronics", "Wallets & Cards", "Keys", "Books & Stationery", "Other"};

    private Chip chipLost;
    private TextInputLayout tilTitle, tilCategory, tilPlace, tilContact, tilLat;
    private TextInputEditText etTitle, etPlace, etContact, etLat, etLon;
    private MaterialAutoCompleteTextView actCategory;
    private MaterialButton btnLocation;

    private Double lat = null, lon = null; // set by "Use my current location"

    private final ActivityResultLauncher<String> permissionLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted || LocationHelper.hasPermission(requireContext())) fetchLocation();
                else ((MainActivity) requireActivity()).showMessage("Location permission is required to tag this item");
            });

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_report, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        chipLost = view.findViewById(R.id.chip_lost);
        tilTitle = view.findViewById(R.id.til_title);
        tilCategory = view.findViewById(R.id.til_category);
        tilPlace = view.findViewById(R.id.til_place);
        tilContact = view.findViewById(R.id.til_contact);
        tilLat = view.findViewById(R.id.til_lat);
        etTitle = view.findViewById(R.id.et_title);
        etPlace = view.findViewById(R.id.et_place);
        etContact = view.findViewById(R.id.et_contact);
        etLat = view.findViewById(R.id.et_lat);
        etLon = view.findViewById(R.id.et_lon);
        actCategory = view.findViewById(R.id.act_category);
        btnLocation = view.findViewById(R.id.btn_location);

        actCategory.setAdapter(new ArrayAdapter<>(requireContext(), android.R.layout.simple_list_item_1, CATEGORIES));

        btnLocation.setOnClickListener(v -> {
            if (LocationHelper.hasPermission(requireContext())) fetchLocation();
            else permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION);
        });

        view.findViewById(R.id.btn_save).setOnClickListener(v -> save());
    }

    private void fetchLocation() {
        btnLocation.setEnabled(false);
        btnLocation.setText("Getting location...");
        LocationHelper.getLocation(requireContext(), new LocationHelper.Callback() {
            @Override
            public void onLocation(Location location) {
                if (!isAdded()) return;
                lat = location.getLatitude();
                lon = location.getLongitude();
                etLat.setText(String.format(Locale.US, "%.5f", lat));
                etLon.setText(String.format(Locale.US, "%.5f", lon));
                tilLat.setError(null);
                resetButton();
            }

            @Override
            public void onError(String message) {
                if (!isAdded()) return;
                ((MainActivity) requireActivity()).showMessage(message);
                resetButton();
            }
        });
    }

    private void resetButton() {
        btnLocation.setEnabled(true);
        btnLocation.setText("Use my current location");
    }

    private void save() {
        String title = etTitle.getText().toString().trim();
        String category = actCategory.getText().toString().trim();
        String place = etPlace.getText().toString().trim();
        String contact = etContact.getText().toString().trim();

        tilTitle.setError(null);
        tilCategory.setError(null);
        tilPlace.setError(null);
        tilContact.setError(null);
        tilLat.setError(null);
        boolean ok = true;

        if (title.length() < 3) {
            tilTitle.setError("At least 3 characters");
            ok = false;
        }
        if (category.isEmpty()) {
            tilCategory.setError("Choose a category");
            ok = false;
        }
        if (place.isEmpty()) {
            tilPlace.setError("Enter the place");
            ok = false;
        }
        if (!contact.matches("03\\d{9}")) {
            tilContact.setError("11 digits starting with 03");
            ok = false;
        }
        if (lat == null || lon == null) {
            tilLat.setError("Tap the location button");
            ok = false;
        }
        if (!ok) return;

        Session session = new Session(requireContext());
        DbHelper db = DbHelper.get(requireContext());

        Item item = new Item();
        item.id = db.nextId();
        item.type = chipLost.isChecked() ? "Lost" : "Found";
        item.title = title;
        item.category = category;
        item.place = place;
        item.contact = contact;
        item.latitude = lat;
        item.longitude = lon;
        item.date = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        item.status = "Open";
        item.reportedBy = session.getName();
        item.reporterEmail = session.getEmail();
        db.addItem(item);

        ((MainActivity) requireActivity()).goHome("Item " + item.id + " reported");
    }
}
