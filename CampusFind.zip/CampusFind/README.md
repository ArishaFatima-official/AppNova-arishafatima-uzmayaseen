# CampusFind

Lost & Found mobile app for University of Lahore students (AppNova).

## Team
- Team name: _your team name_
- Entry ID: _your entry id_
- Members: _names and SAP IDs_

## Stack
- Android Studio, **Java + XML**
- Material Design 3 (black and yellow theme)
- Local database: **SQLite** (`SQLiteOpenHelper`)
- Passwords: salted SHA-256 hash (never plain text)
- Session: `SharedPreferences`
- Location: Android `LocationManager` (no API keys needed)

## Features completed
F1 icon, F2 login/register, F3 bottom nav + profile, F4 home list, F5 item details,
F6 report form, F7 current location, F8 database, F9 session + logout,
F10 open in maps, F11 nearby tab, F12 filter + mark as returned.

## How to run
1. Open the `CampusFind` folder in Android Studio (Hedgehog or newer, JDK 17).
2. Let Gradle sync.
3. Run on an emulator or phone (Android 8.0+).
4. Emulator location: `...` (Extended controls) > Location > set a point near 31.3895, 74.2407.
5. Register an account, then log in.

## Screenshots
Add 3-5 screenshots here.
